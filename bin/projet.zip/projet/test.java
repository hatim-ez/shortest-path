package projet;

public class test {
	
	

	public static void main(String[] args) throws Exception {
		Parcours parcours = new Parcours ("malta.in", 3600000, Long.valueOf(155505557));
		parcours.resultats(300000);
	}

}

package projet;
import java.util.*;
import java.io.*;

public class Graph {
	
	final static int c = 8; // constante utilisee dans la fonction de hachage
	int n; // nombre de sommets
	int m; // nombre d'arcs

	final HashMap<Long, LinkedList<Arc>> graph; // graph, à un sommet on associe tous les arcs sortant
	double[][] coordinates = null; // coordonnees des sommets pour affichage

	// constructeur
	
	
	public Graph(String file) throws Exception {
		
		BufferedReader br = new BufferedReader(new FileReader(file));
		
		String dataLine;
		
		this.n = 0;
		this.m = 0;

		graph = new HashMap<Long, LinkedList<Arc>>();		
		
		while ((dataLine = br.readLine()) != null) {
			String[] tokens = dataLine.split(" ");
			
			if (tokens[0].equals("v")) {  // on ajoute tous les sommets avec une liste d'Arc nuls
				Long i = Long.parseLong(tokens[1]);
				graph.put(i, new LinkedList<Arc>());
				n++;
			}
			if (tokens[0].equals("a")){    // on ajoute les arcs
				Long o= Long.parseLong(tokens[1]);
				Long d= Long.parseLong(tokens[2]);
				int t= Integer.parseInt(tokens[3]);
				graph.get(o).add(new Arc(o,d,t));
				m++;
			}
		}
		br.close();
		System.out.println("done");
	}
	/*
	// mise en place des coordonnees des sommets
	public void setCoordinates(String file) throws Exception {
		System.out.print("Loading geometric coordinates from file " + file + " ... ");
		BufferedReader br = new BufferedReader(new FileReader(file));

		String dataLine = br.readLine();
		while (dataLine.charAt(0) != 'a')
			dataLine = br.readLine();

		String[] tokens = dataLine.split("\\s");
		int nPoints = Integer.parseInt(tokens[4]);
		if (nPoints != this.n){
			br.close();
			throw new Error("The number of points does not match the number of nodes in the graph");
		}

		this.coordinates = new double[this.n][2];

		while ((dataLine = br.readLine()) != null) {
			tokens = dataLine.split("\\s");
			if (tokens[0].equals("v")) {
				int node = Integer.parseInt(tokens[1]);
				double x = Double.parseDouble(tokens[2]);
				double y = Double.parseDouble(tokens[3]);
				this.coordinates[node - 1][0] = x / 1000000.;
				this.coordinates[node - 1][1] = y / 1000000.;
			}
		}
		br.close();
		System.out.println("done");
	}
	*/
	public LinkedList<Arc> successors(Long i) {
		
		return  graph.get(i);
		
	}
	/*
	// ajout d'un nouvel arc pondere
	public void addWeightedArc(int i, int j, int v) {
		this.weights.put(new Arc(i, j), v);
	}

	// poids de l'arc (i,j) s'il existe, 0 sinon
	public int weight(int i, int j) {
		if (!this.weights.containsKey(new Arc(i, j)))
			return 0;
		return this.weights.get(new Arc(i, j));
	}

	// renvoie le graphe ou toutes les orientations ont ete inversees
	public Graph reverse() {
		HashMap<Arc, Integer> map = new HashMap<Arc, Integer>(c * n);
		for (int i = 0; i < n; i++) {
			for (Integer j : this.succ[i]) {
				int val = this.weight(i, j);
				map.put(new Arc(j, i), val);
			}
		}
		Graph rg=new Graph(n, m, pred, succ, map);
		rg.coordinates=coordinates;
		return rg;
	}

	// affichage d'un graphe en chaine
	public String toString() {
		String s = "n=" + n + '\n' + "m=" + m + '\n';
		for (int i = 0; i < n; i++) {
			s = s + "Node " + i + " :" + '\n';
			for (int k : succ[i])
				s = s + "   " + i + " - " + k + " (" + this.weight(i, k) + ")"
						+ '\n';
		}
		return s;
	}
	*/
	// fonctions d'affichage

	// dessin du graphe
	
	/*
	public void drawGraph(Fenetre f) {
		if (f != null && this.coordinates != null) { // verification donnees geometriques
			for (int i = 0; i < this.n; i++) {
				double x1 = this.coordinates[i][0];
				double y1 = this.coordinates[i][1];
				for (Integer j : this.pred[i]) {
					double x2 = this.coordinates[j][0];
					double y2 = this.coordinates[j][1];
					f.addSegment(x1, y1, x2, y2, 1, Color.BLACK);
				}
				f.addPoint(x1, y1, 1, Color.BLACK);
			}
		}
	}

	// dessiner un point traite (rouge)
	public void drawSettledPoint(Fenetre f, int p){
		if (f != null && this.coordinates != null) { // verification donnees geometriques
			f.addPoint(this.coordinates[p][0], this.coordinates[p][1], 3, Color.RED);
		}
	}

	// dessiner un point visité et a traiter (vert)
	public void drawUnsettledPoint(Fenetre f, int p){
		if (f != null && this.coordinates != null) { // verification donnees geometriques
			f.addPoint(this.coordinates[p][0], this.coordinates[p][1], 3, Color.GREEN);
		}
	}

	// dessiner la source et la destination
	public void drawSourceDestination(Fenetre f, int origin, int destination) {
		if (f != null && this.coordinates != null) { // verification donnees geometriques
			f.addPoint(this.coordinates[origin][0], this.coordinates[origin][1], 6, Color.BLUE);
			f.addPoint(this.coordinates[destination][0], this.coordinates[destination][1], 6, Color.BLUE);
		}
	}
	
	// dessiner un point special
	public void drawSpecialPoint(Fenetre f, int p) {
		if (f != null && this.coordinates != null) { // verification donnees geometriques
			f.addPoint(this.coordinates[p][0], this.coordinates[p][1], 6, Color.BLUE);
		}
	}

	// dessiner le chemin en utilisant l'information contenue dans pred
	public void drawPath(Fenetre f, int[] pred, int i) {
		if (f != null && this.coordinates != null) { // verification donnees geometriques
			double x1 = this.coordinates[i][0];
			double y1 = this.coordinates[i][1];
			while (pred[i] != -1 && pred[i] != i) {
				double x2 = this.coordinates[pred[i]][0];
				double y2 = this.coordinates[pred[i]][1];
				f.addSegment(x1, y1, x2, y2, 10, Color.BLUE);
				x1 = x2;
				y1 = y2;
				i = pred[i];
			}
		}
	}

	// dessiner le chemin forme de deux morceaux se rejoignant
	public void drawPath(Fenetre f, int[] predF, int[] predB, int x, int i, int j) {
		if (f != null && this.coordinates != null) { // verification donnees geometriques
			if (i == -1) {
				drawPath(f, predF, x);			
				drawPath(f, predB, x);
				drawSpecialPoint(f, x);
			}
			else {
				f.addSegment(this.coordinates[i][0], this.coordinates[i][1], this.coordinates[j][0], this.coordinates[j][1], 10, Color.BLUE);
				drawPath(f, predF, i);
				drawPath(f, predB, j);
				drawSpecialPoint(f, i);
				drawSpecialPoint(f, j);
			}
		}
	}
	
	*/


}

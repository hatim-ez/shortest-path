package projet;

public class Arc {
	Long origin; // origine de l'arc
	Long destination; // destination de l'arc
	int time; // temps de trajet
	
	// constructeur
	public Arc(Long o, Long d, int t) {
		this.origin = o;
		this.destination = d;
		this.time=t;
	}

	// redefinition de la fonction equals
	public boolean equals(Object o) {
		Arc a=(Arc)o;
		return this.origin == a.origin && this.destination == a.destination;
	}
	
	// redefinition du hashCode
	public int hashCode() {  // à réécrire 
		return Graph.c*this.time;
	}
}

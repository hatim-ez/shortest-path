package projet;
import java.util.*;

public class Parcours {
	HashMap<Long, Integer> visited;
	Graph graph;
	int time;
	public Parcours (String fil, int time, Long depart) throws Exception {
		graph = new Graph(fil);
		visited= new HashMap<Long, Integer>();	
		this.time=time;
		// visited contient pour chaque sommet déja visité le temps de trajet, 0 pour le départ
		visited.put(depart,0);
		LinkedList<Arc> list = graph.successors(depart);
		for (Arc arc:list){
			if (arc.time<time){
					visited.put(depart, arc.time);
					parcoursAux(arc.time, arc.destination);
			}
		}
	}
	
	
	
	void parcoursAux(int timeParcouru, Long depart ){
		LinkedList<Arc> list = graph.successors(depart);
		for (Arc arc:list){
			if (arc.time+timeParcouru<time){
				Integer timePrecedent = visited.get(arc.destination);
				if (timePrecedent==null){ // première fois qu'on visite le sommet
					visited.put(arc.destination, timeParcouru+arc.time);
					parcoursAux(timeParcouru+arc.time, arc.destination);
				}
				else {
					if (timePrecedent>timeParcouru+arc.time){  // si ce trajet est plus intéressant on réacualise
						visited.put(arc.destination, timeParcouru+arc.time);
						parcoursAux(timeParcouru+arc.time, arc.destination);
					}
				}
					
			}
		}
		
		
	
	}
	
	void resultats(int timeMin){
		for (Map.Entry<Long,Integer> e : visited.entrySet()){
			if (e.getValue()>timeMin){
				System.out.println("id "+e.getKey()+" temps "+e.getValue());
			}
			
		}
	}

}
